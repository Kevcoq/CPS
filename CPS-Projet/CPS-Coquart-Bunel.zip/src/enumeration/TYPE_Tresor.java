package enumeration;

/**
 * Type des Tresor
 * 
 * @author Kevin & Quentin
 * 
 */
public enum TYPE_Tresor {
	RIEN, DIXDOLLAR, CINQDOLLAR, CHAINEVELO, POUBELLEMETALLIQUE;
}