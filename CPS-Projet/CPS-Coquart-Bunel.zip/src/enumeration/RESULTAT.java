package enumeration;

/**
 * resultat
 * 
 * @author Kevin & Quentin
 * 
 */
public enum RESULTAT {
	GAGNEE, PERDUE, NULLE
}