package enumeration;

/**
 * Type des Bloc
 * 
 * @author Kevin & Quentin
 * 
 */
public enum TYPE_Bloc {
	VIDE, FOSSE
}
