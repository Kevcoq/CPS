package enumeration;

/**
 * Les commandes possible
 * 
 * @author Kevin & Quentin
 * 
 */
public enum COMMANDE {
	RIEN, GAUCHE, DROITE, HAUT, BAS, SAUTER, FRAPPE, JETER, RAMASSER
}