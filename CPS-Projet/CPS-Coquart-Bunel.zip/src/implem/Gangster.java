package implem;

import services.GangsterService;

public class Gangster extends Personnage implements GangsterService {

}
